This dataset has been modified by cropping photos to focus in on the flowers.

The original dataset can be found at:
https://www.tensorflow.org/datasets/catalog/tf_flowers

The contributors and license for original the dataset can be found in LICENSE.txt.
If sharing images generated from this data, please cite the original authors.